import sys

def log(obj):
    print >>sys.stderr, obj
